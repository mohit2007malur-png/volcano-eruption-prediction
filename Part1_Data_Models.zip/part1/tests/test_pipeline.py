"""Unit tests for the data/feature logic.  Run:  python -m pytest -q"""
import numpy as np
import pandas as pd

from src import config
from src.data import load_eruptions, in_east_rift_zone, label_erupting, days_to_next_eruption
from src.features import earthquake_rates, build_dataset
from src.split import make_split


def test_rates_count_only_strictly_earlier_events():
    t = pd.Series(pd.to_datetime(["2000-01-01 00:00", "2000-01-01 12:00",
                                  "2000-01-02 06:00", "2000-01-10 00:00"]))
    assert earthquake_rates(t, 1).tolist() == [0, 1, 1, 0]   # 06:00 on day 2: only 12:00 is <24 h back
    assert earthquake_rates(t, 30).tolist() == [0, 1, 2, 3]


def test_rift_filter_line():
    # A point just below the line is kept, one just above is dropped
    assert in_east_rift_zone(np.array([19.29]), np.array([-155.5]))[0]
    assert not in_east_rift_zone(np.array([19.31]), np.array([-155.5]))[0]


def test_labels_against_episode_1():
    er = load_eruptions()          # episode 1 starts 1983-01-03, lasts 99 h (+24 h buffer)
    t = pd.Series(pd.to_datetime(["1983-01-02 12:00", "1983-01-04 00:00", "1983-01-09 00:00"]))
    y = label_erupting(t, er)
    assert y.tolist() == [0, 1, 0]
    d = days_to_next_eruption(t, er, y)
    assert np.isclose(d[0], 0.5) and d[1] == 0


def test_dataset_matches_paper():
    df = build_dataset(verbose=False)
    assert len(df) == 3764                                   # paper: 3764 quakes
    assert 0.20 < df[config.CLASS_TARGET].mean() < 0.25      # paper: ~80 % repose
    assert df[config.REG_TARGET].notna().all()


def test_split_is_disjoint_and_stratified():
    df = build_dataset(verbose=False)
    s = make_split(df, config.CLASS_TARGET)
    all_idx = np.concatenate([s.idx_train, s.idx_dev, s.idx_test])
    assert len(set(all_idx)) == len(df)
    assert abs(s.y_train.mean() - s.y_test.mean()) < 0.01
    assert abs(s.X_train.mean(axis=0)).max() < 1e-9           # scaler fit on train only
