# Live demo script — part 1 (data, models, evaluation)

Goal: show the teacher that every number and plot is **computed live from the raw data**,
and that you can change something and explain what happens. Read the model numbers off the
screen as they appear; the fixed data facts are listed at the end.

## Running it in Google Colab (you or your teammate)

1. Put `walkthrough.ipynb` and `Part1_Data_Models.zip` in a Google Drive folder and share the
   folder with your teammate.
2. Double-click `walkthrough.ipynb` in Drive → **Open with → Google Colaboratory**.
3. Run the first cell (section 0) → *Choose files* → pick the zip from your computer
   (download it from Drive first if needed). It unpacks the code and data and installs
   scikit-learn 1.9.1 (a few seconds).
4. **Runtime → Run all** (~3–4 min). At the end the browser downloads **`notebook_results.zip`**:
   all figures + metrics + `RESULTS.md` from this exact run. Give that zip to your teammate for
   the report and slides. (If the download is blocked, open the Files panel on the left and
   download `part1/notebook_results.zip` from there.)

Colab wipes uploaded files when the session ends, so redo step 3 each new session.
Each person running it gets their own copy; nobody overwrites anyone else's.
If you see "scikit-learn ... is loaded, need 1.9.1": Runtime → Restart session → Run all
(it won't ask for the zip again).

## Before the review (once)

Run the notebook fully once to make sure it works, then **Edit → Clear all outputs** (Colab) or
**Kernel → Restart & Clear Output** (Jupyter), so it opens blank in the review.

## In the review (≈ 5 min)

**1. Show the raw data is the starting point (30 s)**
Open `data/raw/` and show the two CSVs: 6,485 earthquakes and 49 eruption episodes.
Say: "Nothing is precomputed. The notebook starts from these two files."

**2. Run the notebook top to bottom (≈ 2–3 min, talk while it runs)**
Runtime → Run all. As each section finishes, point at:

| Section | What appears | What to say |
|---|---|---|
| 2 | map with the filter line | "6,485 → 3,764 quakes: we keep the East Rift Zone near the vent" |
| 3 | weekly count vs red bands, 22.4 % | "Labels come from the eruption calendar; classes are imbalanced" |
| 4 | feature table, box plots | "Rates = earlier quakes in the last 1/7/30 days; higher during eruptions" |
| 6 | 77.7 % accuracy, kappa 0 | "That's why we use kappa and AUROC, not accuracy" |
| 8 | elbow plots | "k = 8 where the curve flattens" |
| 9 | depth curve | "Train goes to 1.0 (memorising), dev flattens; we pick the start of the plateau" |
| 11 | results table, ROC, confusion | "Random forest has the highest kappa and AUROC" — read the numbers off the table |
| 12 | regression table, importance | "Random forest best again; the 30-day rate is the most important feature" |
| 13 | random vs month-grouped bars | "Without leakage it drops to near chance, so earthquakes alone aren't enough" |
| 15 | "Saved: ..." + download | "Every figure and number you saw is saved from this run, for the report" |

**3. Change something live (1 min) — the strongest proof**
In the first settings cell set `DROP_FEATURE = "eq_rate_30d"` and `RUN_NN = False`, then
Runtime → Run all (under a minute).
- The random forest's test AUROC drops clearly.
- Then try `DROP_FEATURE = "magnitude"`: AUROC barely moves.
- Say: "This matches the feature-importance plot: the 30-day rate carries the signal, magnitude doesn't."
Set it back to `None` afterwards.

**4. Predict a new earthquake (30 s)**
Last cell: set `eq_rate_1d/7d/30d` to `60, 200, 300` → high P(erupting);
to `1, 10, 60` → low P(erupting).

**5. If asked "where's the actual code?"**
Open `src/`: `data.py` (filter + labels), `features.py` (rates), `split.py`,
`models/random_forest.py`, etc. The notebook imports these; `main.py` runs the same pipeline as a
script and saves all figures and metrics to `results/`.

## Backup if Colab or the internet fails

On a laptop with the requirements installed:
```bash
python main.py --no-nn      # same pipeline in the terminal, < 1 min, writes results/
python demo.py --date 1983-01-08
```

## Fixed facts (same on every machine)

6,485 earthquakes → 3,764 in the East Rift Zone · 49 eruption episodes · 22.4 % erupting
(844 / 2,920) · 70/20/10 split = 2,634 / 753 / 377 · naive "always repose" = 77.7 % accuracy,
kappa 0, AUROC 0.5 · 7 features · seed 42 · k = 8 (classification), 10 (regression)
