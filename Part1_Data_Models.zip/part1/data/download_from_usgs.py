"""
Re-download the Kilauea earthquake catalogue straight from the USGS / ANSS ComCat API,
using the same selection as our file:

    1 Jan 1983 - 31 Dec 1986, within 30 km of Kilauea summit (19.421 N, 155.287 W), magnitude > 1.5

    python data/download_from_usgs.py

Saves data/raw/usgs_comcat_download.csv (it does NOT replace the file the project uses) and
compares it with our catalogue. USGS keeps revising old events (relocations, recomputed
magnitudes), so today's count is a little higher than the 6,485 in our 2019 extract.
"""
from pathlib import Path
from urllib.parse import urlencode

import pandas as pd

RAW = Path(__file__).resolve().parent / "raw"
PARAMS = {
    "format": "csv",
    "starttime": "1983-01-01",
    "endtime": "1986-12-31",
    "latitude": 19.421, "longitude": -155.287, "maxradiuskm": 30,   # Kilauea summit, 30 km
    "minmagnitude": 1.505,                                          # our file: all M > 1.5
    "orderby": "time-asc",
}
URL = "https://earthquake.usgs.gov/fdsnws/event/1/query?" + urlencode(PARAMS)


def main():
    print("Downloading from:\n ", URL)
    usgs = pd.read_csv(URL)
    out = RAW / "usgs_comcat_download.csv"
    usgs.to_csv(out, index=False)
    ours = pd.read_csv(RAW / "kilauea_earthquakes_1983_1986.csv")
    print(f"\nUSGS today : {len(usgs):,} earthquakes  (saved to {out.name})")
    print(f"Our file   : {len(ours):,} earthquakes  (WOVOdat extract used by the paper)")
    print("\nFirst rows from USGS:")
    print(usgs[["time", "latitude", "longitude", "depth", "mag"]].head().to_string(index=False))


if __name__ == "__main__":
    main()
