# Dataset card

## Sources

| File | What it is | Original source | Rows |
|---|---|---|---|
| `raw/kilauea_earthquakes_1983_1986.csv` | Earthquake catalogue, Kilauea, 1 Jan 1983 – 30 Dec 1986 | Advanced National Seismic System (ANSS) catalogue, retrieved via WOVOdat (World Organization of Volcano Observatories database) | 6,485 |
| `raw/puuoo_eruption_episodes.csv` | Pu'u 'O'o eruption episodes 1–48 (incl. 35.5) | Hawaii Center for Volcanology, Pu'u 'O'o eruption chronology | 49 |

Both files are the ones published with the reference paper (Mullet, Singh & Wong, CS229 2019,
github.com/bmullet/PEEVED), copied unchanged and renamed. We used the paper's copies so our results
are directly comparable with theirs.

### Where the original data lives (to show or re-download)

**Earthquakes — USGS / ANSS ComCat.** Our file is exactly this selection
(we checked: the `Distance` column is the distance from Kilauea summit, max 30 km; all M > 1.5):

- 1 Jan 1983 – 31 Dec 1986, within **30 km of Kilauea summit (19.421° N, 155.287° W)**, magnitude **> 1.5**
- Search page: https://earthquake.usgs.gov/earthquakes/search/ (enter the values above)
- API, same query as CSV:
  `https://earthquake.usgs.gov/fdsnws/event/1/query?format=csv&starttime=1983-01-01&endtime=1986-12-31&latitude=19.421&longitude=-155.287&maxradiuskm=30&minmagnitude=1.505`
- Script: `python data/download_from_usgs.py` (saves a separate file, does not touch ours)

Today USGS returns **6,723** events for this query vs **6,485** in our extract (checked 11 Oct 2026).
The catalogue is revised over time: e.g. our first quake (1 Jan 1983 00:18:51, M 1.92) is in ComCat
as `hv19825076`, relocated ~0.4 km and re-rated M 1.95 in a 2020 update. Same source, newer version.

**Eruption episodes — Hawaii Center for Volcanology (University of Hawaiʻi).**
"Episodes of the Pu'u 'O'o Eruption of Kilauea":
https://www.soest.hawaii.edu/earthsciences_archive/HCV/puuoo-episodes.html
Our CSV is that table (same columns and values). Episode 48 is listed there as "~5.5 yrs", which
the CSV stores as a placeholder number of hours.
Detailed episode history: USGS Scientific Investigations Report 2018-5109,
https://pubs.usgs.gov/publication/sir20185109

## Raw columns

**Earthquakes:** `Date-time` (UTC, mm/dd/yyyy hh:mm:ss), `Latitude`, `Longitude`, `Depth` (km),
`Magnitude`, `Magnitude-type`, `Earthquake-type`, `Distance` (km from the volcano), `Data-Owner`.
Only time, latitude, longitude, depth and magnitude are used.

**Eruption episodes:** `Number`, `Date` (start, day precision), `Repose` (days since previous
episode), `Length` (e.g. "99 hrs"), `Flow Area`, `Flow Volume`, `Rate`, `Location`.
Only the start date and length are used. `-9999` = missing (only in flow columns, not used).

## Cleaning and quirks handled (`src/data.py`)

1. **Spatial filter → East Rift Zone.** Keep a quake if it lies on/below the straight line through
   (lon −155.5, lat 19.3) and (lon −155.0, lat 19.5). 6,485 → **3,764 quakes** (same as the paper).
2. **Episode 48** (Kupaianaha, 20 Jul 1986) has a placeholder length of 173,566,800 hrs — it was
   still erupting at the end of the record → treated as open-ended.
3. **Episode 35.5** is listed before episode 35 in the file → episodes are sorted by start date.
4. **24-hour buffer** added to every episode's end, because start dates are only known to the day.

## Labels (targets)

| Column | Task | Definition |
|---|---|---|
| `erupting` | A — classification | 1 if the quake time is inside `[start, start + length + 24 h)` of any episode, else 0 |
| `days_to_eruption` | B — regression | days until the next episode start; 0 if erupting |

Class balance: **844 erupting (22.4 %) / 2,920 repose (77.6 %)**.
`days_to_eruption`: mean 12.4 days, median 9.0, max 63.9.

## Features (`src/features.py` → `processed/features.csv`)

| Feature | Meaning | Range in data |
|---|---|---|
| `longitude`, `latitude` | epicentre location | −155.52…−155.00, 19.16…19.44 |
| `depth` | hypocentre depth, km | 0.01…29.97 |
| `magnitude` | magnitude | 1.51…5.66 |
| `eq_rate_1d` | number of earlier rift-zone quakes in the previous 1 day | 0…134 |
| `eq_rate_7d` | … previous 7 days | 0…363 |
| `eq_rate_30d` | … previous 30 days | 0…521 |

Rates count **strictly earlier** quakes only (no peeking at the future), computed with binary
search on the sorted times.

`features.csv` also contains `time` and `month` (calendar month, used to group quakes for the
leakage check). 48 distinct months.

## Sanity checks

- Gutenberg–Richter b-value = **0.98** (expected ≈ 1 for a complete catalogue) — figure 03.
- 0 missing values in any feature or target.
