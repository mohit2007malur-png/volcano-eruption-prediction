"""
Step 2 - Feature engineering.

Raw columns per earthquake: longitude, latitude, depth, magnitude.
Derived "earthquake rate" features: how many East-Rift-Zone earthquakes happened
in the 1 / 7 / 30 days BEFORE this one. Physical idea: magma moving into the
rift changes crustal stress and produces swarms, so rate should rise around
eruptions.

Run this file directly to rebuild data/processed/features.csv:
    python -m src.features
"""
import numpy as np
import pandas as pd

from . import config
from .data import (load_earthquakes, load_eruptions, in_east_rift_zone,
                   label_erupting, days_to_next_eruption)


def earthquake_rates(times: pd.Series, window_days: float) -> np.ndarray:
    """
    Count of earlier earthquakes in the half-open window [t - window, t).

    The array is time-sorted, so two binary searches give the answer in
    O(n log n) instead of the O(n^2) double loop.
    """
    t = times.values.astype("datetime64[ns]")
    left = np.searchsorted(t, t - np.timedelta64(int(window_days * 86400), "s"), side="left")
    right = np.searchsorted(t, t, side="left")          # strictly earlier events only
    return (right - left).astype(float)


def build_dataset(verbose: bool = True) -> pd.DataFrame:
    eqs = load_earthquakes()
    eruptions = load_eruptions()

    mask = in_east_rift_zone(eqs["latitude"].values, eqs["longitude"].values)
    df = eqs[mask].reset_index(drop=True)

    for name, days in config.RATE_WINDOWS_DAYS.items():
        df[name] = earthquake_rates(df["time"], days)

    df[config.CLASS_TARGET] = label_erupting(df["time"], eruptions)
    df[config.REG_TARGET] = days_to_next_eruption(df["time"], eruptions, df[config.CLASS_TARGET].values)
    # Month id used later for the leakage-free "grouped" evaluation.
    df["month"] = df["time"].dt.to_period("M").astype(str)

    if verbose:
        print(f"Catalogue earthquakes        : {len(eqs)}")
        print(f"East Rift Zone earthquakes   : {len(df)}")
        print(f"Erupting fraction            : {df[config.CLASS_TARGET].mean():.3f}")
        print(f"Missing days_to_eruption     : {df[config.REG_TARGET].isna().sum()}")
    return df


def main():
    config.DATA_PROCESSED.mkdir(parents=True, exist_ok=True)
    df = build_dataset()
    df.to_csv(config.FEATURES_CSV, index=False)
    print(f"Saved -> {config.FEATURES_CSV.relative_to(config.ROOT)}")


if __name__ == "__main__":
    main()
