"""
Step 1 - Load the two raw tables and turn them into labelled earthquakes.

  * kilauea_earthquakes_1983_1986.csv : ANSS catalogue (via WOVOdat) - one row per
    earthquake with time, latitude, longitude, depth (km) and magnitude.
  * puuoo_eruption_episodes.csv       : Hawaii Center for Volcanology list of the
    Pu'u 'O'o eruption episodes - start date + duration in hours.

From these we derive, for every earthquake,
  erupting         : 1 if the volcano was erupting when it happened, else 0
  days_to_eruption : how long until the next episode starts (0 if erupting)
"""
import numpy as np
import pandas as pd

from . import config


# --------------------------------------------------------------------- loaders
def load_earthquakes(path=config.EARTHQUAKE_CSV) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = df.rename(columns={
        "Date-time": "time", "Latitude": "latitude", "Longitude": "longitude",
        "Depth": "depth", "Magnitude": "magnitude",
    })
    df["time"] = pd.to_datetime(df["time"], format="%m/%d/%Y %H:%M:%S")
    df = df[["time", "latitude", "longitude", "depth", "magnitude"]]
    return df.sort_values("time").reset_index(drop=True)


def load_eruptions(path=config.ERUPTION_CSV) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["start"] = pd.to_datetime(df["Date"], format="%m/%d/%y")
    df["length_hours"] = df["Length"].str.replace(" hrs", "", regex=False).astype(float)
    # Episode 48 (Kupaianaha, July 1986) has a placeholder length of ~173 million
    # hours: it simply never stopped during our window -> treat as open-ended.
    end = df["start"] + pd.to_timedelta(
        np.minimum(df["length_hours"], 1e6) + config.ERUPTION_BUFFER_HOURS, unit="h")
    df["end"] = end
    df = df.rename(columns={"Number": "episode", "Location": "location"})
    # Rows are not perfectly date-ordered in the source file (episode 35.5).
    return df[["episode", "start", "end", "length_hours", "location"]] \
        .sort_values("start").reset_index(drop=True)


# --------------------------------------------------------------------- filters
def in_east_rift_zone(lat: np.ndarray, lon: np.ndarray) -> np.ndarray:
    """True for points on/below the line through the two RIFT_LINE_POINTS."""
    (x1, y1), (x2, y2) = config.RIFT_LINE_POINTS
    slope = (y2 - y1) / (x2 - x1)
    intercept = y1 - slope * x1
    return lat - (slope * lon + intercept) <= 0


# --------------------------------------------------------------------- labels
def label_erupting(times: pd.Series, eruptions: pd.DataFrame) -> np.ndarray:
    """1 if the time falls inside ANY episode's [start, end) window."""
    t = times.values[:, None]
    inside = (t >= eruptions["start"].values[None, :]) & (t < eruptions["end"].values[None, :])
    return inside.any(axis=1).astype(int)


def days_to_next_eruption(times: pd.Series, eruptions: pd.DataFrame,
                          erupting: np.ndarray) -> np.ndarray:
    """Days until the next episode start; 0 while erupting; NaN if none follows."""
    starts = eruptions["start"].values
    idx = np.searchsorted(starts, times.values, side="right")   # first start > t
    out = np.full(len(times), np.nan)
    has_next = idx < len(starts)
    out[has_next] = (starts[idx[has_next]] - times.values[has_next]) / np.timedelta64(1, "D")
    out[erupting == 1] = 0.0
    return out
