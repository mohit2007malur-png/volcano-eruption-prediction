"""
Step 4 - Train, tune and evaluate every model for both tasks.

Task A  "contemporaneous eruption classification"
        x = one earthquake's features  ->  is the volcano erupting right now? (0/1)
Task B  "time-to-eruption regression"
        x = one earthquake's features  ->  how long until the next eruption starts?

Protocol (identical for every model):
    fit on TRAIN  ->  choose hyperparameters on DEV  ->  report once on TEST
"""
import json
import time

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, cohen_kappa_score, r2_score

from . import config, plots
from .data import load_eruptions
from .features import build_dataset
from .metrics import classification_metrics, regression_metrics
from .split import make_split
from .models.logistic import train_logistic
from .models.kmeans_model import KMeansClassifier, KMeansRegressor, elbow_curve
from .models.random_forest import tune_random_forest, _make
from .models.neural_net import tune_neural_net


def _eval_cls(model, s):
    out = {}
    for name, X, y in [("train", s.X_train, s.y_train), ("dev", s.X_dev, s.y_dev),
                       ("test", s.X_test, s.y_test)]:
        score = model.predict_proba(X)[:, 1] if hasattr(model, "predict_proba") else model.predict_score(X)
        out[name] = classification_metrics(y, model.predict(X), score)
    return out


def _eval_reg(model, s):
    return {name: regression_metrics(y, model.predict(X))
            for name, X, y in [("train", s.X_train, s.y_train), ("dev", s.X_dev, s.y_dev),
                               ("test", s.X_test, s.y_test)]}


# ======================================================================= Task A
def run_classification(df, use_nn=True):
    print("\n=== Task A: contemporaneous eruption classification ===")
    s = make_split(df, config.CLASS_TARGET)
    print(f"  split sizes  train={len(s.y_train)} dev={len(s.y_dev)} test={len(s.y_test)}  "
          f"(erupting: {s.y_train.mean():.3f}/{s.y_dev.mean():.3f}/{s.y_test.mean():.3f})")

    naive = classification_metrics(s.y_test, np.zeros_like(s.y_test), np.zeros(len(s.y_test)))
    print(f"  naive 'never erupting' baseline on test: accuracy={naive['accuracy']:.3f}, "
          f"kappa={naive['kappa']:.2f}, AUROC={naive['auroc']:.2f}")

    models, extra = {}, {}
    models["Logistic Regression"] = train_logistic(s.X_train, s.y_train)

    ks0, in0 = elbow_curve(s.X_train[s.y_train == 0])
    ks1, in1 = elbow_curve(s.X_train[s.y_train == 1])
    extra["elbow"] = {"repose": (ks0, in0), "erupting": (ks1, in1)}
    models["K-means"] = KMeansClassifier().fit(s.X_train, s.y_train)

    rf, rf_info = tune_random_forest("classification", s.X_train, s.y_train, s.X_dev, s.y_dev)
    models["Random Forest"] = rf
    extra["rf"] = rf_info

    if use_nn:
        t0 = time.time()
        nn_model, nn_info = tune_neural_net("classification", s.X_train, s.y_train, s.X_dev, s.y_dev)
        models["Neural Network"] = nn_model
        extra["nn"] = nn_info | {"history": nn_model.history, "seconds": time.time() - t0}

    results = {name: _eval_cls(m, s) for name, m in models.items()}
    results_with_base = {"Naive baseline": {"test": naive}} | results
    _print_cls_table(results)
    return s, models, results_with_base, extra


def _print_cls_table(results):
    print(f"\n  {'Model':<20}{'split':<7}{'kappa':>7}{'AUROC':>7}{'recall':>8}  confusion")
    for m, r in results.items():
        for sp in ("train", "dev", "test"):
            x = r[sp]
            print(f"  {m:<20}{sp:<7}{x['kappa']:>7.2f}{x['auroc']:>7.2f}{x['recall']:>8.2f}  {x['confusion']}")


# ======================================================================= Task B
def run_regression(df, use_nn=True):
    print("\n=== Task B: time-to-eruption regression ===")
    s = make_split(df, config.REG_TARGET, scale_target=True)
    models, extra = {}, {}

    ks, inertia = elbow_curve(np.column_stack([s.X_train, s.y_train]))
    extra["elbow"] = (ks, inertia)
    models["K-means"] = KMeansRegressor().fit(s.X_train, s.y_train)

    rf, rf_info = tune_random_forest("regression", s.X_train, s.y_train, s.X_dev, s.y_dev)
    models["Random Forest"] = rf
    all_tree_imp = np.array([t.feature_importances_ for t in rf.estimators_])
    rf_info["importance"] = {"mean": rf.feature_importances_, "std": all_tree_imp.std(axis=0)}
    extra["rf"] = rf_info

    if use_nn:
        nn_model, nn_info = tune_neural_net("regression", s.X_train, s.y_train, s.X_dev, s.y_dev)
        models["Neural Network"] = nn_model
        extra["nn"] = nn_info | {"history": nn_model.history}

    results = {name: _eval_reg(m, s) for name, m in models.items()}
    print(f"\n  {'Model':<20}{'RMSE train/dev/test':<24}{'R2 train/dev/test'}")
    for m, r in results.items():
        rm = "/".join(f"{r[k]['rmse']:.2f}" for k in ("train", "dev", "test"))
        r2 = "/".join(f"{r[k]['r2']:.2f}" for k in ("train", "dev", "test"))
        print(f"  {m:<20}{rm:<24}{r2}")
    sd = s.y_scaler.scale_[0]
    print(f"  (1 standardised unit = {sd:.1f} days; RF test RMSE = "
          f"{results['Random Forest']['test']['rmse'] * sd:.1f} days)")
    return s, models, results, extra


# ======================================================================= Extension
def run_leakage_check(df, rf_cls_info, rf_reg_info):
    """
    Earthquakes come in swarms: neighbours in time share almost identical
    rate features AND the same label. A RANDOM split puts swarm-mates in both
    train and test, so the model can 'recognise the swarm' instead of learning
    anything general. Grouping all quakes of one calendar month into the same
    fold removes that shortcut. Same RF hyperparameters, 5 folds each.
    """
    print("\n=== Extension: random vs. month-grouped 5-fold cross-validation (RF) ===")
    X = df[config.FEATURES].values
    yc = df[config.CLASS_TARGET].values
    yr = df[config.REG_TARGET].values
    groups = df["month"].values

    def cv(splitter, split_args):
        auc, kap, r2 = [], [], []
        for tr, te in splitter.split(X, *split_args):
            sc = StandardScaler().fit(X[tr])
            Xtr, Xte = sc.transform(X[tr]), sc.transform(X[te])
            if len(np.unique(yc[te])) == 2:
                m = _make("classification", rf_cls_info["best_depth"], rf_cls_info["best_trees"]).fit(Xtr, yc[tr])
                auc.append(roc_auc_score(yc[te], m.predict_proba(Xte)[:, 1]))
                kap.append(cohen_kappa_score(yc[te], m.predict(Xte)))
            ys = StandardScaler().fit(yr[tr].reshape(-1, 1))
            mr = _make("regression", rf_reg_info["best_depth"], rf_reg_info["best_trees"]).fit(
                Xtr, ys.transform(yr[tr].reshape(-1, 1)).ravel())
            r2.append(r2_score(ys.transform(yr[te].reshape(-1, 1)).ravel(), mr.predict(Xte)))
        return {"auroc": float(np.mean(auc)), "kappa": float(np.mean(kap)), "r2": float(np.mean(r2))}

    rand = cv(StratifiedKFold(5, shuffle=True, random_state=config.SEED), (yc,))
    grp = cv(GroupKFold(5), (yc, groups))
    for k in ("auroc", "kappa", "r2"):
        print(f"  {k:<6} random split: {rand[k]:.2f}   month-grouped: {grp[k]:.2f}")
    return {"random_split": rand, "grouped_by_month": grp}


# ======================================================================= main
def _json_default(o):
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    raise TypeError(type(o))


def run_all(use_nn=True):
    config.METRICS.mkdir(parents=True, exist_ok=True)
    config.MODELS_DIR.mkdir(parents=True, exist_ok=True)

    df = build_dataset()
    df.to_csv(config.FEATURES_CSV, index=False)
    eruptions = load_eruptions()

    # ---- exploratory figures
    plots.plot_map(df)
    plots.plot_timeline(df, eruptions)
    b_value = plots.plot_gutenberg_richter(df)
    print(f"Gutenberg-Richter b-value: {b_value:.2f}")

    # ---- Task A
    sc, mc, rc, ec = run_classification(df, use_nn)
    # ---- Task B
    sr, mr, rr, er = run_regression(df, use_nn)
    # ---- Extension
    leak = run_leakage_check(df, ec["rf"], er["rf"])

    # ---- figures
    plots.plot_elbows({
        "Classification - repose quakes": (*ec["elbow"]["repose"], config.KMEANS_K_CLASSIFY),
        "Classification - erupting quakes": (*ec["elbow"]["erupting"], config.KMEANS_K_CLASSIFY),
        "Regression - features + target": (*er["elbow"], config.KMEANS_K_REGRESS),
    })
    plots.plot_rf_tuning(ec["rf"]["curve"], ec["rf"]["best_depth"], "AUROC",
                         "05_rf_depth_tuning_classification.png", "RF depth tuning - classification")
    plots.plot_rf_tuning(er["rf"]["curve"], er["rf"]["best_depth"], "R²",
                         "06_rf_depth_tuning_regression.png", "RF depth tuning - regression")
    if use_nn:
        plots.plot_nn_history({"NN - classification (BCE)": ec["nn"]["history"],
                               "NN - regression (MSE)": er["nn"]["history"]})
    model_results = {k: v for k, v in rc.items() if k != "Naive baseline"}
    plots.plot_classification_comparison(model_results)
    plots.plot_confusions(model_results)
    plots.plot_roc(sc.y_test, {n: (m.predict_proba(sc.X_test)[:, 1] if hasattr(m, "predict_proba")
                                   else m.predict_score(sc.X_test)) for n, m in mc.items()})
    plots.plot_regression_comparison(rr)
    rf_r = mr["Random Forest"]
    plots.plot_rf_regression_detail(er["rf"]["importance"], sr.y_test, rf_r.predict(sr.X_test))
    names = {"auroc": "Classification\nAUROC", "kappa": "Classification\nCohen's kappa",
             "r2": "Regression\nR²"}
    plots.plot_leakage({names[k]: leak["random_split"][k] for k in names},
                       {names[k]: leak["grouped_by_month"][k] for k in names})

    # ---- save metrics
    summary = {
        "dataset": {"n_earthquakes": int(len(df)), "erupting_fraction": float(df.erupting.mean()),
                    "gutenberg_richter_b": float(b_value),
                    "days_per_std_unit": float(sr.y_scaler.scale_[0])},
        "classification": rc, "regression": rr, "leakage_check": leak,
        "hyperparameters": {
            "rf_classification": {k: ec["rf"][k] for k in ("best_depth", "best_trees")},
            "rf_regression": {k: er["rf"][k] for k in ("best_depth", "best_trees")},
            "rf_regression_importance": dict(zip(config.FEATURES, er["rf"]["importance"]["mean"])),
            **({"nn_classification": {k: ec["nn"][k] for k in ("lr", "weight_decay", "best_epoch", "n_params")},
                "nn_regression": {k: er["nn"][k] for k in ("lr", "weight_decay", "best_epoch", "n_params")}}
               if use_nn else {}),
        },
    }
    with open(config.METRICS / "results.json", "w") as f:
        json.dump(summary, f, indent=2, default=_json_default)
    _write_tables(rc, rr)

    # ---- save the models the demo needs
    joblib.dump({"scaler": sc.x_scaler, "model": mc["Random Forest"]}, config.MODELS_DIR / "rf_classifier.joblib")
    joblib.dump({"scaler": sr.x_scaler, "y_scaler": sr.y_scaler, "model": mr["Random Forest"]},
                config.MODELS_DIR / "rf_regressor.joblib")
    print(f"\nSaved metrics -> results/metrics/, figures -> results/figures/, models -> results/models/")
    return summary


def _write_tables(rc, rr):
    rows = []
    for m, r in rc.items():
        for sp, x in r.items():
            rows.append({"model": m, "split": sp, "kappa": round(x["kappa"], 3),
                         "auroc": round(x["auroc"], 3), "accuracy": round(x["accuracy"], 3),
                         "recall": round(x["recall"], 3), "precision": round(x["precision"], 3),
                         "confusion [[TN,FP],[FN,TP]]": x["confusion"]})
    pd.DataFrame(rows).to_csv(config.METRICS / "classification_results.csv", index=False)
    rows = [{"model": m, "split": sp, "rmse_std": round(x["rmse"], 3), "r2": round(x["r2"], 3)}
            for m, r in rr.items() for sp, x in r.items()]
    pd.DataFrame(rows).to_csv(config.METRICS / "regression_results.csv", index=False)
