"""
Evaluation metrics.

Why not accuracy? ~78 % of earthquakes happen during repose, so a model that
always answers "not erupting" is 78 % accurate and completely useless.

Classification
  * Cohen's kappa = (p_o - p_e) / (1 - p_e): agreement corrected for chance.
      0 = no better than chance, 1 = perfect. Uses hard 0/1 predictions.
  * AUROC: probability that a random erupting quake gets a higher score than a
      random repose quake. 0.5 = random, 1 = perfect. Uses the model's SCORES.
  * Confusion matrix [[TN, FP], [FN, TP]].

Regression
  * RMSE on the standardised target (same units as the paper's table).
  * R^2 = 1 - SS_res / SS_tot (fraction of variance explained).
"""
import numpy as np
from sklearn import metrics


def classification_metrics(y_true, y_pred, y_score) -> dict:
    cm = metrics.confusion_matrix(y_true, y_pred, labels=[0, 1])
    return {
        "kappa": float(metrics.cohen_kappa_score(y_true, y_pred)),
        "auroc": float(metrics.roc_auc_score(y_true, y_score)),
        "accuracy": float(metrics.accuracy_score(y_true, y_pred)),
        "recall": float(metrics.recall_score(y_true, y_pred, zero_division=0)),
        "precision": float(metrics.precision_score(y_true, y_pred, zero_division=0)),
        "confusion": cm.tolist(),
    }


def regression_metrics(y_true, y_pred) -> dict:
    return {
        "rmse": float(np.sqrt(metrics.mean_squared_error(y_true, y_pred))),
        "r2": float(metrics.r2_score(y_true, y_pred)),
    }
