"""
Model 4 - Fully-connected neural network (PyTorch).

Architecture (same as the paper):
    7 inputs -> 1000 -> 1000 -> 1000 -> 1000 -> 1 output   (ReLU between layers)
    ~3.0 million trainable weights

Classification: sigmoid output + binary cross-entropy
    L_BCE = -(1/N) * sum[ y log(y_hat) + (1-y) log(1-y_hat) ]
Regression: linear output + mean squared error
    L_MSE =  (1/N) * sum( y - y_hat )^2

Optimiser: SGD (momentum 0.9), batch size 50, L2 regularisation via weight decay.
Learning rate and weight decay are grid-searched on the dev set; for every run we
keep the epoch with the best dev score (early-stopping checkpoint).
"""
import copy
import itertools

import numpy as np
import torch
from torch import nn
from sklearn.metrics import roc_auc_score, r2_score

from .. import config

torch.set_num_threads(max(1, torch.get_num_threads()))


class MLP(nn.Module):
    def __init__(self, n_in, hidden=config.NN_HIDDEN):
        super().__init__()
        layers, prev = [], n_in
        for h in hidden:
            layers += [nn.Linear(prev, h), nn.ReLU()]
            prev = h
        layers.append(nn.Linear(prev, 1))   # raw output (logit for classification)
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x).squeeze(-1)


def n_params(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


class NNModel:
    """sklearn-like wrapper so the experiment code treats every model the same."""

    def __init__(self, task, lr, weight_decay, epochs=config.NN_EPOCHS):
        self.task, self.lr, self.wd, self.epochs = task, lr, weight_decay, epochs

    def _dev_score(self, X, y):
        out = self._raw(X)
        if self.task == "classification":
            return roc_auc_score(y, out)
        return r2_score(y, out)

    def _raw(self, X):
        self.model.eval()
        with torch.no_grad():
            out = self.model(torch.tensor(X, dtype=torch.float32))
            if self.task == "classification":
                out = torch.sigmoid(out)
        return out.numpy()

    def fit(self, X_tr, y_tr, X_dv, y_dv):
        torch.manual_seed(config.SEED)
        self.model = MLP(X_tr.shape[1])
        loss_fn = nn.BCEWithLogitsLoss() if self.task == "classification" else nn.MSELoss()
        opt = torch.optim.SGD(self.model.parameters(), lr=self.lr, momentum=0.9,
                              weight_decay=self.wd)
        Xt = torch.tensor(X_tr, dtype=torch.float32)
        yt = torch.tensor(y_tr, dtype=torch.float32)
        Xd = torch.tensor(X_dv, dtype=torch.float32)
        yd = torch.tensor(y_dv, dtype=torch.float32)
        g = torch.Generator().manual_seed(config.SEED)

        self.history = {"train_loss": [], "dev_loss": [], "dev_score": []}
        best, best_state = -np.inf, None
        for _ in range(self.epochs):
            self.model.train()
            perm = torch.randperm(len(Xt), generator=g)
            total = 0.0
            for i in range(0, len(Xt), config.NN_BATCH):
                b = perm[i:i + config.NN_BATCH]
                opt.zero_grad()
                loss = loss_fn(self.model(Xt[b]), yt[b])
                loss.backward()
                opt.step()
                total += loss.item() * len(b)
            self.model.eval()
            with torch.no_grad():
                dev_loss = loss_fn(self.model(Xd), yd).item()
            score = self._dev_score(X_dv, y_dv)
            self.history["train_loss"].append(total / len(Xt))
            self.history["dev_loss"].append(dev_loss)
            self.history["dev_score"].append(score)
            if score > best:
                best, best_state = score, copy.deepcopy(self.model.state_dict())
                self.best_epoch = len(self.history["dev_score"])
        self.model.load_state_dict(best_state)
        self.best_dev = best
        return self

    # --- prediction API
    def predict_score(self, X):
        return self._raw(X)

    def predict(self, X):
        out = self._raw(X)
        return (out >= 0.5).astype(int) if self.task == "classification" else out


def tune_neural_net(task, X_tr, y_tr, X_dv, y_dv, verbose=True):
    results, best = [], None
    for lr, wd in itertools.product(config.NN_LRS, config.NN_WEIGHT_DECAYS):
        m = NNModel(task, lr, wd).fit(X_tr, y_tr, X_dv, y_dv)
        results.append({"lr": lr, "weight_decay": wd, "dev_score": m.best_dev,
                        "best_epoch": m.best_epoch})
        if verbose:
            print(f"  NN ({task}) lr={lr:<5} wd={wd:<6} -> best dev {m.best_dev:.3f} "
                  f"@ epoch {m.best_epoch}")
        if best is None or m.best_dev > best.best_dev:
            best = m
    return best, {"grid": results, "lr": best.lr, "weight_decay": best.wd,
                  "best_epoch": best.best_epoch, "n_params": n_params(best.model)}
