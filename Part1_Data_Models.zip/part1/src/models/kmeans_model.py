"""
Model 2 - K-means clustering used as a predictor (the paper's "modified k-means").

Classification
  1. Split TRAIN into repose quakes and erupting quakes.
  2. Run k-means (k = 8, chosen by the elbow method) separately on each group.
     -> 8 "typical repose quake" centroids + 8 "typical erupting quake" centroids.
  3. A new quake gets the label of its nearest centroid.
     Score for AUROC = d_repose / (d_repose + d_erupt)  (closer to erupt -> higher).

Regression (time to eruption)
  1. Cluster TRAIN on [features, time_to_eruption] together (k = 10).
  2. For a new quake, find the nearest centroid using the FEATURE part only,
     and predict that centroid's time_to_eruption coordinate.
  -> only k possible output values, which is why it regresses poorly.
"""
import numpy as np
from sklearn.cluster import KMeans

from .. import config


def elbow_curve(X, k_range=config.KMEANS_K_RANGE):
    """Inertia (within-cluster sum of squares) for each k - look for the 'elbow'."""
    ks = list(k_range)
    inertia = [KMeans(n_clusters=k, n_init=10, random_state=config.SEED).fit(X).inertia_ for k in ks]
    return ks, inertia


def _min_dist(X, centroids):
    return np.linalg.norm(X[:, None, :] - centroids[None, :, :], axis=2).min(axis=1)


class KMeansClassifier:
    def __init__(self, k=config.KMEANS_K_CLASSIFY):
        self.k = k

    def fit(self, X, y):
        self.km0 = KMeans(self.k, n_init=10, random_state=config.SEED).fit(X[y == 0])
        self.km1 = KMeans(self.k, n_init=10, random_state=config.SEED).fit(X[y == 1])
        return self

    def predict_score(self, X):
        d0 = _min_dist(X, self.km0.cluster_centers_)
        d1 = _min_dist(X, self.km1.cluster_centers_)
        return d0 / (d0 + d1 + 1e-12)

    def predict(self, X):
        return (self.predict_score(X) > 0.5).astype(int)   # nearer an erupting centroid


class KMeansRegressor:
    def __init__(self, k=config.KMEANS_K_REGRESS):
        self.k = k

    def fit(self, X, y):
        self.km = KMeans(self.k, n_init=10, random_state=config.SEED).fit(np.column_stack([X, y]))
        self.centroid_X = self.km.cluster_centers_[:, :-1]
        self.centroid_y = self.km.cluster_centers_[:, -1]
        return self

    def predict(self, X):
        nearest = np.linalg.norm(X[:, None, :] - self.centroid_X[None], axis=2).argmin(axis=1)
        return self.centroid_y[nearest]
