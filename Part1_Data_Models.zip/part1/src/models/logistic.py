"""
Model 1 - Logistic regression (classification only, as in the paper).

p(erupting | x) = sigmoid(w . x + b); trained by minimising log-loss.
A linear decision boundary - the simplest sensible baseline.
"""
from sklearn.linear_model import LogisticRegression

from .. import config


def train_logistic(X_train, y_train):
    return LogisticRegression(solver="lbfgs", random_state=config.SEED).fit(X_train, y_train)
