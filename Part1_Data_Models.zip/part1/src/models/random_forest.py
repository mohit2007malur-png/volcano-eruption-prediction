"""
Model 3 - Random forest (classification and regression).

Many decision trees, each grown on a bootstrap sample and allowed to look at only
`max_features` random features at every split. Deep trees -> low bias;
averaging many de-correlated trees -> low variance.

Tuning (on the DEV set, never the test set):
  1. Sweep max_depth 1..30 with 100 trees, record train & dev score
     (AUROC for classification, R^2 for regression) -> tuning curve figure.
  2. Pick the SMALLEST depth whose dev score is within 0.005 of the best
     ("start of the plateau" - same reasoning as the paper's Figure 3).
  3. With that depth, choose the number of trees.
"""
import numpy as np
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import roc_auc_score, r2_score

from .. import config


def _make(task, depth, n_trees):
    cls = RandomForestClassifier if task == "classification" else RandomForestRegressor
    return cls(n_estimators=n_trees, max_depth=depth, max_features=config.RF_MAX_FEATURES,
               random_state=config.SEED, n_jobs=-1)


def _score(task, model, X, y):
    if task == "classification":
        return roc_auc_score(y, model.predict_proba(X)[:, 1])
    return r2_score(y, model.predict(X))


def tune_random_forest(task, X_tr, y_tr, X_dv, y_dv, verbose=True):
    curve = {"depth": [], "train": [], "dev": []}
    for d in config.RF_DEPTHS:
        m = _make(task, d, 100).fit(X_tr, y_tr)
        curve["depth"].append(d)
        curve["train"].append(_score(task, m, X_tr, y_tr))
        curve["dev"].append(_score(task, m, X_dv, y_dv))
    dev = np.array(curve["dev"])
    best_depth = int(np.array(curve["depth"])[np.argmax(dev >= dev.max() - 0.005)])

    tree_scores = {}
    for n in config.RF_N_TREES:
        tree_scores[n] = _score(task, _make(task, best_depth, n).fit(X_tr, y_tr), X_dv, y_dv)
    best_trees = max(tree_scores, key=tree_scores.get)
    if verbose:
        print(f"  RF ({task}): best max_depth={best_depth}, n_estimators={best_trees}, "
              f"dev score={tree_scores[best_trees]:.3f}")

    model = _make(task, best_depth, best_trees).fit(X_tr, y_tr)
    return model, {"curve": curve, "best_depth": best_depth,
                   "best_trees": best_trees, "tree_scores": tree_scores}
