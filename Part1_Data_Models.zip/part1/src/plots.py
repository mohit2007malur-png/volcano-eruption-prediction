"""
All figures. One consistent style: thin marks, recessive grid, fixed colour per model
(the same model is always the same colour in every figure).
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve

from . import config

INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
MODEL_COLORS = {
    "Logistic Regression": "#2a78d6",
    "K-means": "#eb6834",
    "Random Forest": "#1baf7a",
    "Neural Network": "#4a3aa7",
}
ERUPT, REPOSE = "#e34948", "#2a78d6"
SEQ = LinearSegmentedColormap.from_list("seq_blue", ["#b9d4f3", "#2a78d6", "#0d2f5c"])

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10, "axes.titlesize": 11,
    "axes.titleweight": "bold", "axes.edgecolor": INK2, "axes.labelcolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.6, "axes.spines.top": False, "axes.spines.right": False,
    "axes.axisbelow": True, "legend.frameon": False, "savefig.dpi": 200,
    "savefig.bbox": "tight", "figure.facecolor": "white",
})


def _save(fig, name):
    config.FIGURES.mkdir(parents=True, exist_ok=True)
    fig.savefig(config.FIGURES / name)
    plt.close(fig)


# ------------------------------------------------------------------ data exploration
def plot_map(df):
    fig, ax = plt.subplots(figsize=(7, 4))
    sc = ax.scatter(df.longitude, df.latitude, c=df.depth, cmap=SEQ, s=6, lw=0, vmax=15)
    ax.plot(*config.PUU_OO_LOCATION, marker="^", color=ERUPT, ms=11, mec="white", mew=1.5,
            ls="none", label="Pu'u 'O'o vent")
    fig.colorbar(sc, ax=ax, label="Depth (km)", extend="max")
    ax.set(xlabel="Longitude", ylabel="Latitude",
           title=f"East Rift Zone earthquakes, Kilauea 1983-86 (n = {len(df)})")
    ax.set_aspect("equal")
    ax.legend(loc="upper left")
    _save(fig, "01_earthquake_map.png")


def plot_timeline(df, eruptions):
    weekly = df.set_index("time").resample("W").size()
    fig, ax = plt.subplots(figsize=(10, 3.2))
    for _, e in eruptions.iterrows():
        end = min(e.end, pd.Timestamp("1987-01-01"))
        ax.axvspan(e.start, end, color=ERUPT, alpha=0.22, lw=0)
    ax.plot(weekly.index, weekly.values, color=REPOSE, lw=1.4)
    ax.set(ylabel="Earthquakes per week", yscale="log",
           title="Weekly East-Rift earthquake count (line) vs. eruption episodes (red bands)")
    ax.set_xlim(pd.Timestamp("1983-01-01"), pd.Timestamp("1987-01-01"))
    _save(fig, "02_timeline_rates_vs_eruptions.png")


def plot_gutenberg_richter(df):
    mags = np.sort(df.magnitude.values)
    bins = np.arange(1.5, mags.max() + 0.1, 0.1)
    n_ge = np.array([(mags >= m).sum() for m in bins])
    fit = (bins <= 4) & (n_ge > 0)
    slope, intercept = np.polyfit(bins[fit], np.log10(n_ge[fit]), 1)
    fig, ax = plt.subplots(figsize=(5, 3.5))
    ax.semilogy(bins, n_ge, "o", color=REPOSE, ms=4, label="observed")
    ax.semilogy(bins, 10 ** (intercept + slope * bins), color=ERUPT, lw=2,
                label=f"fit: log N = {intercept:.2f} - {abs(slope):.2f} M")
    ax.set(xlabel="Magnitude M", ylabel="# earthquakes >= M",
           title="Gutenberg-Richter frequency-magnitude")
    ax.legend()
    _save(fig, "03_gutenberg_richter.png")
    return -slope


# ------------------------------------------------------------------ tuning curves
def plot_elbows(curves):
    fig, axes = plt.subplots(1, len(curves), figsize=(4 * len(curves), 3.2))
    for ax, (title, (ks, inertia, chosen)) in zip(np.atleast_1d(axes), curves.items()):
        ax.plot(ks, inertia, "-o", color=REPOSE, lw=2, ms=4)
        ax.axvline(chosen, color=ERUPT, ls="--", lw=1.2)
        ax.annotate(f"k = {chosen}", (chosen, max(inertia)), xytext=(5, -5),
                    textcoords="offset points", color=INK, va="top")
        ax.set(title=title, xlabel="Number of clusters k", ylabel="Inertia")
    fig.suptitle("K-means elbow method", fontweight="bold")
    fig.tight_layout()
    _save(fig, "04_kmeans_elbow.png")


def plot_rf_tuning(curve, best_depth, metric, fname, title):
    fig, ax = plt.subplots(figsize=(5.5, 3.5))
    ax.plot(curve["depth"], curve["train"], color=REPOSE, lw=2, label="train")
    ax.plot(curve["depth"], curve["dev"], color=ERUPT, lw=2, label="dev")
    ax.axvline(best_depth, color=INK2, ls="--", lw=1)
    ax.annotate(f"chosen depth = {best_depth}", (best_depth, min(curve["dev"])),
                xytext=(5, 5), textcoords="offset points", color=INK)
    ax.set(xlabel="max_depth", ylabel=metric, title=title)
    ax.legend()
    _save(fig, fname)


def plot_nn_history(histories):
    fig, axes = plt.subplots(1, len(histories), figsize=(5 * len(histories), 3.3))
    for ax, (title, h) in zip(np.atleast_1d(axes), histories.items()):
        ep = np.arange(1, len(h["train_loss"]) + 1)
        ax.plot(ep, h["train_loss"], color=REPOSE, lw=2, label="train loss")
        ax.plot(ep, h["dev_loss"], color=ERUPT, lw=2, label="dev loss")
        ax.set(title=title, xlabel="Epoch", ylabel="Loss")
        ax.legend()
    fig.tight_layout()
    _save(fig, "07_nn_loss_curves.png")


# ------------------------------------------------------------------ results
def plot_classification_comparison(results):
    models = list(results)
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.4))
    for ax, metric, label in zip(axes, ["kappa", "auroc"], ["Cohen's kappa", "AUROC"]):
        x = np.arange(len(models))
        w = 0.26
        for j, (split, alpha) in enumerate([("train", 0.35), ("dev", 0.65), ("test", 1.0)]):
            vals = [results[m][split][metric] for m in models]
            bars = ax.bar(x + (j - 1) * w, vals, w * 0.92, color=[MODEL_COLORS[m] for m in models],
                          alpha=alpha, label=split)
            if split == "test":
                for b, v in zip(bars, vals):
                    ax.text(b.get_x() + b.get_width() / 2, v + 0.01, f"{v:.2f}",
                            ha="center", fontsize=8, color=INK)
        if metric == "auroc":
            ax.axhline(0.5, color=INK2, ls=":", lw=1)
        ax.set_xticks(x, [m.replace(" ", "\n") for m in models])
        ax.set(title=f"{label}  (faded -> solid = train, dev, test)", ylim=(0, 1.08))
    fig.tight_layout()
    _save(fig, "08_classification_comparison.png")


def plot_confusions(results):
    models = list(results)
    fig, axes = plt.subplots(1, len(models), figsize=(3.1 * len(models), 3))
    for ax, m in zip(axes, models):
        cm = np.array(results[m]["test"]["confusion"])
        ax.imshow(cm, cmap=SEQ, vmin=0, vmax=cm.max())
        for (i, j), v in np.ndenumerate(cm):
            ax.text(j, i, v, ha="center", va="center", fontsize=12,
                    color="white" if v > cm.max() * 0.5 else INK)
        ax.set_xticks([0, 1], ["repose", "erupt"])
        ax.set_yticks([0, 1], ["repose", "erupt"])
        ax.set(xlabel="Predicted", ylabel="Actual" if m == models[0] else "", title=m)
        ax.grid(False)
    fig.suptitle("Test-set confusion matrices", fontweight="bold")
    fig.tight_layout()
    _save(fig, "09_confusion_matrices.png")


def plot_roc(y_test, scores):
    fig, ax = plt.subplots(figsize=(4.8, 4.2))
    for m, s in scores.items():
        fpr, tpr, _ = roc_curve(y_test, s)
        ax.plot(fpr, tpr, color=MODEL_COLORS[m], lw=2, label=m)
    ax.plot([0, 1], [0, 1], color=INK2, ls=":", lw=1, label="random (0.5)")
    ax.set(xlabel="False positive rate", ylabel="True positive rate",
           title="ROC curves (test set)")
    ax.legend(loc="lower right", fontsize=8)
    _save(fig, "10_roc_curves.png")


def plot_regression_comparison(results):
    models = list(results)
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.4))
    for ax, metric, label in zip(axes, ["rmse", "r2"], ["RMSE (standardised)", "R²"]):
        x = np.arange(len(models)); w = 0.26
        for j, (split, alpha) in enumerate([("train", 0.35), ("dev", 0.65), ("test", 1.0)]):
            vals = [results[m][split][metric] for m in models]
            bars = ax.bar(x + (j - 1) * w, vals, w * 0.92, color=[MODEL_COLORS[m] for m in models],
                          alpha=alpha)
            if split == "test":
                for b, v in zip(bars, vals):
                    ax.text(b.get_x() + b.get_width() / 2, max(v, 0) + 0.01, f"{v:.2f}",
                            ha="center", fontsize=8, color=INK)
        ax.axhline(0, color=INK2, lw=0.8)
        ax.set_xticks(x, [m.replace(" ", "\n") for m in models])
        ax.set(title=f"{label}  (faded -> solid = train, dev, test)")
    fig.tight_layout()
    _save(fig, "11_regression_comparison.png")


def plot_rf_regression_detail(importances, y_test, y_pred):
    order = np.argsort(importances["mean"])[::-1]
    names = np.array(config.FEATURES)[order]
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    ax = axes[0]
    ax.bar(range(len(names)), importances["mean"][order], yerr=importances["std"][order],
           color=MODEL_COLORS["Random Forest"], ecolor=INK2, capsize=3, width=0.7)
    ax.set_xticks(range(len(names)), names, rotation=35, ha="right")
    ax.set(title="Random forest feature importance", ylabel="Mean decrease in impurity")
    ax = axes[1]
    ax.scatter(y_pred, y_test, s=10, color=ERUPT, alpha=0.6, lw=0)
    lim = [min(y_pred.min(), y_test.min()) - 0.2, max(y_pred.max(), y_test.max()) + 0.2]
    ax.plot(lim, lim, color=REPOSE, ls="--", lw=1.5, label="perfect prediction")
    ax.set(xlim=lim, ylim=lim, xlabel="Predicted time-to-eruption (std.)",
           ylabel="Observed time-to-eruption (std.)", title="Random forest - test set")
    ax.legend(loc="upper left")
    fig.tight_layout()
    _save(fig, "12_rf_regression_importance_and_fit.png")


def plot_leakage(random_scores, grouped_scores):
    labels = list(random_scores)
    x = np.arange(len(labels)); w = 0.36
    fig, ax = plt.subplots(figsize=(7, 3.6))
    b1 = ax.bar(x - w / 2, [random_scores[k] for k in labels], w * 0.92, color=REPOSE,
                label="random split (paper protocol)")
    b2 = ax.bar(x + w / 2, [grouped_scores[k] for k in labels], w * 0.92, color="#eb6834",
                label="grouped by month (no leakage)")
    for bars in (b1, b2):
        for b in bars:
            v = b.get_height()
            ax.text(b.get_x() + b.get_width() / 2, v + (0.02 if v >= 0 else -0.07),
                    f"{v:.2f}", ha="center", fontsize=9, color=INK)
    ax.axhline(0, color=INK2, lw=0.8)
    ax.set_xticks(x, labels)
    ax.set(ylabel="Score (higher = better)", ylim=(-0.3, 1.15),
           title="Random forest, 5-fold CV: random vs. month-grouped folds")
    ax.legend(loc="upper center", ncol=2, fontsize=8.5, bbox_to_anchor=(0.5, 1.0))
    _save(fig, "13_leakage_random_vs_grouped.png")
