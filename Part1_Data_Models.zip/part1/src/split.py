"""
Step 3 - Train / dev / test split and feature scaling.

70 / 20 / 10 split, stratified on the eruption label so each split keeps the
same ~22 % eruption rate (as in the paper).

The StandardScaler is FIT ON TRAIN ONLY and then applied to dev/test - fitting
it on all data would leak test-set statistics into training.
"""
from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from . import config


@dataclass
class Split:
    X_train: np.ndarray
    X_dev: np.ndarray
    X_test: np.ndarray
    y_train: np.ndarray
    y_dev: np.ndarray
    y_test: np.ndarray
    idx_train: np.ndarray
    idx_dev: np.ndarray
    idx_test: np.ndarray
    x_scaler: StandardScaler
    y_scaler: StandardScaler | None = None


def split_indices(labels: np.ndarray, seed: int = config.SEED):
    idx = np.arange(len(labels))
    idx_train, idx_rest = train_test_split(
        idx, train_size=config.TRAIN_FRAC, stratify=labels, random_state=seed)
    dev_share = config.DEV_FRAC / (config.DEV_FRAC + config.TEST_FRAC)
    idx_dev, idx_test = train_test_split(
        idx_rest, train_size=dev_share, stratify=labels[idx_rest], random_state=seed)
    return idx_train, idx_dev, idx_test


def make_split(df: pd.DataFrame, target: str, scale_target: bool = False) -> Split:
    X = df[config.FEATURES].values.astype(float)
    y = df[target].values.astype(float)
    # Always stratify on the eruption label, also for regression (as in the paper)
    i_tr, i_dv, i_te = split_indices(df[config.CLASS_TARGET].values)

    xs = StandardScaler().fit(X[i_tr])
    ys = None
    y_tr, y_dv, y_te = y[i_tr], y[i_dv], y[i_te]
    if scale_target:
        ys = StandardScaler().fit(y_tr.reshape(-1, 1))
        y_tr, y_dv, y_te = (ys.transform(v.reshape(-1, 1)).ravel() for v in (y_tr, y_dv, y_te))
    else:
        y_tr, y_dv, y_te = y_tr.astype(int), y_dv.astype(int), y_te.astype(int)

    return Split(xs.transform(X[i_tr]), xs.transform(X[i_dv]), xs.transform(X[i_te]),
                 y_tr, y_dv, y_te, i_tr, i_dv, i_te, xs, ys)
