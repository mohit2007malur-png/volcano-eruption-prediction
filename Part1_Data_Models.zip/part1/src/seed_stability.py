"""
Seed-stability check: how much do the random-forest test scores move if we only
change the random 70/20/10 split?  (Same hyperparameters as the main run.)

    python -m src.seed_stability
"""
import json

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import cohen_kappa_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from . import config


def main(n_seeds: int = 20):
    df = pd.read_csv(config.FEATURES_CSV)
    X, y = df[config.FEATURES].values, df[config.CLASS_TARGET].values
    kappas, aurocs = [], []
    for seed in range(n_seeds):
        idx = np.arange(len(y))
        tr, rest = train_test_split(idx, train_size=0.7, stratify=y, random_state=seed)
        dv, te = train_test_split(rest, train_size=2 / 3, stratify=y[rest], random_state=seed)
        sc = StandardScaler().fit(X[tr])
        rf = RandomForestClassifier(200, max_depth=13, max_features=config.RF_MAX_FEATURES,
                                    random_state=0, n_jobs=-1).fit(sc.transform(X[tr]), y[tr])
        p = rf.predict_proba(sc.transform(X[te]))[:, 1]
        kappas.append(cohen_kappa_score(y[te], p >= 0.5))
        aurocs.append(roc_auc_score(y[te], p))
    out = {name: {"mean": float(np.mean(v)), "std": float(np.std(v)),
                  "min": float(np.min(v)), "max": float(np.max(v))}
           for name, v in (("kappa", kappas), ("auroc", aurocs))}
    for k, v in out.items():
        print(f"RF test {k:<6} over {n_seeds} splits: mean {v['mean']:.2f}  sd {v['std']:.2f}  "
              f"range {v['min']:.2f}-{v['max']:.2f}")
    config.METRICS.mkdir(parents=True, exist_ok=True)
    with open(config.METRICS / "seed_stability.json", "w") as f:
        json.dump(out, f, indent=2)


if __name__ == "__main__":
    main()
