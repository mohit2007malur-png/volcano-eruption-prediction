"""
Central configuration: every path, constant and hyperparameter grid lives here
so that experiments are reproducible and nothing is "magic" inside the code.
"""
from pathlib import Path

# ---------------------------------------------------------------- paths
ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "raw"
DATA_PROCESSED = ROOT / "data" / "processed"
RESULTS = ROOT / "results"
FIGURES = RESULTS / "figures"
METRICS = RESULTS / "metrics"
MODELS_DIR = RESULTS / "models"

EARTHQUAKE_CSV = DATA_RAW / "kilauea_earthquakes_1983_1986.csv"
ERUPTION_CSV = DATA_RAW / "puuoo_eruption_episodes.csv"
FEATURES_CSV = DATA_PROCESSED / "features.csv"

# ---------------------------------------------------------------- geography
# Pu'u 'O'o crater (lon, lat) - the vent where the 1983-86 episodes happened.
PUU_OO_LOCATION = (-155.1050, 19.3864)

# East Rift Zone filter: keep earthquakes on/below the straight line that
# passes through (lon=-155.5, lat=19.3) and (lon=-155.0, lat=19.5).
# Same rule as the original paper's code.
RIFT_LINE_POINTS = ((-155.5, 19.3), (-155.0, 19.5))

# ---------------------------------------------------------------- labels
# Episode start dates are only known to the day, so the paper adds a 24 h
# buffer after each episode's recorded length before calling it "over".
ERUPTION_BUFFER_HOURS = 24

# ---------------------------------------------------------------- features
FEATURES = [
    "longitude", "latitude", "depth", "magnitude",
    "eq_rate_1d", "eq_rate_7d", "eq_rate_30d",
]
RATE_WINDOWS_DAYS = {"eq_rate_1d": 1, "eq_rate_7d": 7, "eq_rate_30d": 30}
CLASS_TARGET = "erupting"              # 1 = erupting, 0 = repose
REG_TARGET = "days_to_eruption"        # 0 if already erupting

# ---------------------------------------------------------------- split
SEED = 42
TRAIN_FRAC, DEV_FRAC, TEST_FRAC = 0.70, 0.20, 0.10

# ---------------------------------------------------------------- models
KMEANS_K_RANGE = range(2, 21)          # tried for the elbow plot
KMEANS_K_CLASSIFY = 8                  # per class (paper: elbow at 8)
KMEANS_K_REGRESS = 10                  # paper: elbow at 10

RF_DEPTHS = list(range(1, 31))
RF_N_TREES = [50, 100, 200, 400]
RF_MAX_FEATURES = 3                    # paper: int(sqrt(p)) ~= 3 features per split

NN_HIDDEN = [1000, 1000, 1000, 1000]   # four fully-connected hidden layers
NN_BATCH = 50
NN_EPOCHS = 60
NN_LRS = [0.01, 0.05]
NN_WEIGHT_DECAYS = [1e-4, 1e-3]
