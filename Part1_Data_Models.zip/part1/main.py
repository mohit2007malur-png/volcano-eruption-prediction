"""
Run the whole project end to end:

    python main.py            # everything (about 5-15 min on a laptop CPU)
    python main.py --no-nn    # skip the neural network (under 1 min)
"""
import argparse
import time

from src.experiments import run_all


def main():
    p = argparse.ArgumentParser(description="Predicting eruptive events at Kilauea from earthquake data")
    p.add_argument("--no-nn", action="store_true", help="skip the (slow) neural network")
    args = p.parse_args()
    t0 = time.time()
    run_all(use_nn=not args.no_nn)
    print(f"Done in {time.time() - t0:.0f} s")


if __name__ == "__main__":
    main()
