"""
Live demo for the review session. Uses the trained random-forest models saved by main.py.

  python demo.py                       # 8 random TEST-set earthquakes: prediction vs truth
  python demo.py --date 1983-01-08     # every earthquake on one day (this day episode 1 ends)
  python demo.py --custom 19.33 -155.12 7.5 2.1 12 40 110
        # lat lon depth magnitude quakes_last_1d quakes_last_7d quakes_last_30d
"""
import argparse
import sys

import joblib
import numpy as np
import pandas as pd

from src import config
from src.split import make_split


def load_models():
    try:
        clf = joblib.load(config.MODELS_DIR / "rf_classifier.joblib")
        reg = joblib.load(config.MODELS_DIR / "rf_regressor.joblib")
    except FileNotFoundError:
        sys.exit("Models not found - run `python main.py --no-nn` first.")
    return clf, reg


def predict(X_raw, clf, reg):
    p_erupt = clf["model"].predict_proba(clf["scaler"].transform(X_raw))[:, 1]
    days_std = reg["model"].predict(reg["scaler"].transform(X_raw))
    days = reg["y_scaler"].inverse_transform(days_std.reshape(-1, 1)).ravel()
    return p_erupt, np.clip(days, 0, None)


def show(df, p, days, split_of=None):
    out = pd.DataFrame({
        "time": df["time"].astype(str).str[:16],
        "mag": df["magnitude"].round(2),
        "quakes_7d": df["eq_rate_7d"].astype(int),
        "P(erupting)": p.round(2),
        "predicted": np.where(p >= 0.5, "ERUPTING", "repose"),
    })
    if "erupting" in df:
        out["actual"] = np.where(df["erupting"] == 1, "ERUPTING", "repose")
        out["pred days->eruption"] = days.round(1)
        out["actual days"] = df["days_to_eruption"].round(1)
        out["correct?"] = np.where(out["predicted"] == out["actual"], "yes", "NO")
    if split_of is not None:
        out["seen in"] = [split_of[i] for i in df.index]
    print(out.to_string(index=False))
    if split_of is not None:
        print("\n'seen in' = which split the quake belonged to. 'train' rows were used to fit the "
              "model,\nso only 'dev'/'test' rows are honest out-of-sample predictions.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", help="YYYY-MM-DD between 1983-01-01 and 1986-12-30")
    ap.add_argument("--custom", nargs=7, type=float, metavar="V")
    ap.add_argument("--n", type=int, default=8)
    args = ap.parse_args()

    clf, reg = load_models()
    print("Kilauea eruption predictor - random forest\n")

    if args.custom:
        X = np.array(args.custom)[[1, 0, 2, 3, 4, 5, 6]].reshape(1, -1)  # -> lon, lat, ...
        p, d = predict(X, clf, reg)
        print(f"P(volcano erupting now) = {p[0]:.2f}  ->  {'ERUPTING' if p[0] >= 0.5 else 'repose'}")
        print(f"Predicted time until next eruption = {d[0]:.1f} days")
        return

    df = pd.read_csv(config.FEATURES_CSV, parse_dates=["time"])
    s = make_split(df, config.CLASS_TARGET)
    split_of = {}
    for name, idx in (("train", s.idx_train), ("dev", s.idx_dev), ("TEST", s.idx_test)):
        split_of.update(dict.fromkeys(idx, name))
    if args.date:
        sel = df[df["time"].dt.strftime("%Y-%m-%d") == args.date]
        if sel.empty:
            sys.exit(f"No East-Rift earthquakes recorded on {args.date}.")
        print(f"All {len(sel)} earthquakes on {args.date}:\n")
    else:
        rng = np.random.default_rng()
        sel = df.iloc[rng.choice(s.idx_test, size=args.n, replace=False)].sort_values("time")
        print(f"{args.n} random earthquakes from the held-out TEST set:\n")
    p, d = predict(sel[config.FEATURES].values, clf, reg)
    show(sel, p, d, split_of)


if __name__ == "__main__":
    main()
